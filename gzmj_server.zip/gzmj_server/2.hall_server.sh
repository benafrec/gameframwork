node hall_server/app.js ../configs_mac.js
