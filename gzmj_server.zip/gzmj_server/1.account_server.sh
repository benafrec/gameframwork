node ./account_server/app.js ../configs_mac.js
