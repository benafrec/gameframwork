node majiang_server/app.js ../configs_mac.js
