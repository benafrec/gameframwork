nohup ../nodejs/bin/node ./dealer_server/dealer_server.js ../configs_dealer.js &
