nohup node ./account_server/app.js ../configs.js &
nohup node ./hall_server/app.js ../configs.js &
nohup node ./majiang_server/app.js ../configs.js &